import os
import pickle
import numpy as np
from flask import Flask, request, jsonify, render_template
from tensorflow.keras.models import load_model
from PIL import Image

app = Flask(__name__)

MODEL_PATHS = {
    'cnn': 'saved_models/cnn_model.h5',
    'logreg': 'saved_models/logistic_regression.pkl',
    'svm': 'saved_models/svm.pkl',
    'rf': 'saved_models/random_forest.pkl',
    'kmeans': 'saved_models/kmeans.pkl'
}

models = {
    'cnn': load_model(MODEL_PATHS['cnn']),
    'logreg': pickle.load(open(MODEL_PATHS['logreg'], 'rb')),
    'svm': pickle.load(open(MODEL_PATHS['svm'], 'rb')),
    'rf': pickle.load(open(MODEL_PATHS['rf'], 'rb')),
    'kmeans': pickle.load(open(MODEL_PATHS['kmeans'], 'rb'))
}

MODEL_ACCURACIES = {
    'cnn': 95.0,
    'logreg': 85.0,
    'svm': 88.0,
    'rf': 90.0,
    'kmeans': 80.0
}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in {'png', 'jpg', 'jpeg'}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part in the request'}), 400

    file = request.files['file']
    model_name = request.form.get('model')

    if file.filename == '':
        return jsonify({'error': 'No file selected for uploading'}), 400

    if file and allowed_file(file.filename):
        filepath = os.path.join('uploads', file.filename)
        file.save(filepath)

        img = Image.open(filepath).resize((128, 128))
        img_array = np.array(img) / 255.0
        img_flat = img_array.reshape(1, -1)

        if model_name == 'cnn':
            prediction = np.argmax(models['cnn'].predict(img_array.reshape(1, 128, 128, 3)))
        else:
            prediction = models[model_name].predict(img_flat)[0]

        result = 'Cat' if prediction == 0 else 'Dog'
        accuracy = MODEL_ACCURACIES.get(model_name, 'N/A')

        return jsonify({
            'result': result,
            'model': model_name.upper(),
            'accuracy': accuracy,
            'image_url': filepath
        })
    else:
        return jsonify({'error': 'Allowed file types are png, jpg, jpeg'}), 400

if __name__ == '__main__':
    os.makedirs('uploads', exist_ok=True)
    app.run(debug=True)
