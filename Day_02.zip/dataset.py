import os
import cv2
import numpy as np

def preprocess_images(folder_path, img_size=(128, 128)):
    images = []
    labels = []
    print("Starting preprocessing of images...")
    for label, category in enumerate(['cat', 'dog']):
        category_path = os.path.join(folder_path, category)
        if os.path.exists(category_path):
            print(f"Processing category: {category}")
            for file in os.listdir(category_path):
                file_path = os.path.join(category_path, file)
                img = cv2.imread(file_path)
                if img is not None:
                    img = cv2.resize(img, img_size)
                    img = img / 255.0  
                    img = img.flatten()  
                    images.append(img)
                    labels.append(label)
                else:
                    print(f"Could not read image: {file_path}")
        else:
            print(f"Folder not found: {category_path}")
    print("Image preprocessing completed.")
    return np.array(images), np.array(labels)

if __name__ == "__main__":
    dataset_path = r"C:\\Users\\KIIT\\Desktop\\AD Lab\\Day_2\\animals"
    train_images, train_labels = preprocess_images(dataset_path)
    np.save("train_images.npy", train_images)
    np.save("train_labels.npy", train_labels)
    print("Images and labels have been saved as 'train_images.npy' and 'train_labels.npy'.")
