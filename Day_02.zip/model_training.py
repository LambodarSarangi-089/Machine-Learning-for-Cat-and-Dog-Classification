import os
import numpy as np
import pickle
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.cluster import KMeans
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense
from tensorflow.keras.optimizers import Adam

def train_models():
    train_images = np.load("train_images.npy")
    train_labels = np.load("train_labels.npy")
    X_train, X_test, y_train, y_test = train_test_split(
        train_images.reshape(train_images.shape[0], -1), train_labels, test_size=0.2, random_state=42)

    models = {}

    os.makedirs("saved_models", exist_ok=True)

    print("Training Logistic Regression...")
    log_reg = LogisticRegression(max_iter=1000)
    log_reg.fit(X_train, y_train)
    pickle.dump(log_reg, open("saved_models/logistic_regression.pkl", "wb"))
    models['logistic_regression'] = log_reg
    print("Logistic Regression trained and saved successfully!")

    print("Training Random Forest...")
    rf = RandomForestClassifier(n_estimators=100)
    rf.fit(X_train, y_train)
    pickle.dump(rf, open("saved_models/random_forest.pkl", "wb"))
    models['random_forest'] = rf
    print("Random Forest trained and saved successfully!")

    print("Training Support Vector Machine...")
    svm = SVC(kernel='linear')
    svm.fit(X_train, y_train)
    pickle.dump(svm, open("saved_models/svm.pkl", "wb"))
    models['svm'] = svm
    print("Support Vector Machine trained and saved successfully!")

    print("Training K-means Clustering...")
    kmeans = KMeans(n_clusters=2, random_state=42)
    kmeans.fit(X_train)
    pickle.dump(kmeans, open("saved_models/kmeans.pkl", "wb"))
    models['kmeans'] = kmeans
    print("K-means Clustering trained and saved successfully!")

    print("Training Convolutional Neural Network (CNN)...")
    cnn_model = Sequential([
        Conv2D(32, (3, 3), activation='relu', input_shape=(128, 128, 3)),
        MaxPooling2D((2, 2)),
        Conv2D(64, (3, 3), activation='relu'),
        MaxPooling2D((2, 2)),
        Flatten(),
        Dense(128, activation='relu'),
        Dense(2, activation='softmax')
    ])
    cnn_model.compile(optimizer=Adam(), loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    cnn_model.fit(X_train.reshape(-1, 128, 128, 3), y_train, epochs=5, validation_split=0.2)
    cnn_model.save("saved_models/cnn_model.h5")
    print("Convolutional Neural Network (CNN) trained and saved successfully!")

if __name__ == "__main__":
    train_models()
